const mongoose = require("mongoose");
const config = require("../config");

const connect = () => {
   const dbName = config.DB_NAME;

   mongoose.connect(config.MONGO_DB_URL, {
      dbName: dbName,
   });

   mongoose.Promise = Promise;

   // Database connection events
   // When successfully connected
   mongoose.connection.on("connected", () => {
      console.log(`Mongoose default connection open for worker ${process.pid}`);
   });

   // If the connection throws an error
   mongoose.connection.on("error", (err) => {
      console.log(`Mongoose default connection error: ${err}`);
   });

   // When the connection is disconnected
   mongoose.connection.on("disconnected", () => {
      console.log(
         `Mongoose default connection disconnected for worker ${process.pid}`
      );
   });
};

module.exports = connect();
