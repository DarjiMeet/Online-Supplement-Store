const to = require("await-to-js").default;
const { sign, verify } = require("jsonwebtoken");
const { ErrorHandler } = require("../helpers/errors");
const constants = require("../constants");

const generateJWT = (
   payload,
   key = process.env.JWT_SECRET_KEY,
   expiry = process.env.JWT_EXPIRES_IN
) => sign(payload, key, { expiresIn: expiry });

const getTokenFromHeader = async (req) => {
   if (
      req.headers.authorization &&
      req.headers.authorization.split(" ")[0] === "Bearer"
   ) {
      return req.headers.authorization.split(" ")[1];
   }

   const error = new ErrorHandler(constants.ERRORS.AUTH, {
      statusCode: 401,
      message: "Missing or invalid authentication header",
   });

   throw error;
};

const verifyToken = async (token, key = process.env.JWT_SECRET_KEY) =>
   verify(token, key);

const authMiddlewareForForgotPassword = async (req, res, next) => {
   const [err, token] = await to(getTokenFromHeader(req));
   if (err) {
      next(err);
   }

   const [err2, payload] = await to(
      verifyToken(token, process.env.JWT_SECRET_FORGOT_PASSWORD)
   );
   if (err2) {
      const error = new ErrorHandler(constants.ERRORS.AUTH, {
         statusCode: 401,
         errStack: err2,
         message: "JWT authentication failed",
      });
      next(error);
   }
   res.locals.decode = payload;
   next();
};

const authMiddlewareForLogin = async (req, res, next) => {
   const [err, token] = await to(getTokenFromHeader(req));
   if (err) {
      next(err);
   }

   const [err2, payload] = await to(
      verifyToken(token, process.env.JWT_SECRET_KEY)
   );
   if (err2) {
      const error = new ErrorHandler(constants.ERRORS.AUTH, {
         statusCode: 401,
         errStack: err2,
         message: "JWT authentication failed",
      });
      next(error);
   }
   res.locals.decode = payload;
   next();
};

module.exports = {
   authMiddlewareForForgotPassword,
   generateJWT,
   verifyToken,
   getTokenFromHeader,
   authMiddlewareForLogin,
};
