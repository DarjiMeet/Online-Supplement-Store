const express = require("express");
const bodyParser = require("body-parser");
const routes = require("./routes");
const cors = require("cors");
const { errorHandler } = require("./helpers/errors");
require("./helpers/dbConnections");

const app = express();
const port = process.env.PORT;

app.use(bodyParser.urlencoded({ extended: true }));
app.use((req, res, next) => {
   res.setHeader("Access-Control-Allow-Origin", "http://localhost:3000");
   res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE");
   res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
   next();
});
app.use(cors());

app.get("/", (req, res, next) => {
   return res.send("you are ate backend");
});

app.use("/", routes);

//error handler
app.use(errorHandler);

app.listen(port, () => {
   console.log(`App running on ${port}`);
});
