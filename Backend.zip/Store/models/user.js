const mongoose = require("mongoose");
const { Schema } = mongoose;

const userSchmea = new Schema(
   {
      usrename: {
         type: String,
         trim: true,
      },

      email: {
         type: String,
         trim: true,
         unique: true,
      },

      contact: {
         type: String,
         trim: true,
      },

      address: {
         type: String,
         trim: true,
      },

      password: {
         type: String,
         trim: true,
         required: true,
      },

      orders: {
         type: Array,
         default: {},
      },
   },

   { timestamps: { createdAt: "createdAt", updatedAt: "updatedAt" } }
);

module.exports = mongoose.model("Users", userSchmea);
