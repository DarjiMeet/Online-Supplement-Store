const constants = require('./constants.json');

module.exports = constants;
