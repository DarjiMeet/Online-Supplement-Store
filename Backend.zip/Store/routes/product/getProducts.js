const { products } = require("../../dummyData/products");

module.exports = (req, res, next) => {
   const filteredProducts = products.filter(
      (product) => !product.singleproduct
   );
   return res.status(200).send(filteredProducts);
};
