const { products } = require("../../dummyData/products");

module.exports = (req, res, next) => {
   const id = req.params.id;
   const single = products.find(
      (product) => product.id === id && product.singleproduct === true
   );
   if (!single) {
      // If no product is found, send a 404 response
      return res.status(404).json({ error: "Product not found" });
   }
   return res.status(200).json(single);
};
