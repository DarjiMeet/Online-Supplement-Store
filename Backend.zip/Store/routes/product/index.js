const getProducts = require("./getProducts");
const getSingleProduct = require("./getSingleProduct");

const router = require("express").Router({ mergeParams: true });

router.get("/", getProducts);
router.get("/:id", getSingleProduct);

module.exports = router;
