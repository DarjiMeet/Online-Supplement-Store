const users = require("../../models/user");

module.exports = async (req, res, next) => {
   const { email } = res.locals.decode;

   try {
      const user = await users.findOne({ email: email });
      return res.status(200).send(user.orders);
   } catch (error) {
      console.log(error);
      return res.status(500).send("something bad happen");
   }
};
