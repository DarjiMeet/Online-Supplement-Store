const user = require("../../models/user");

module.exports = async (req, res, next) => {
   const { email } = res.locals.decode;

   try {
      if (req.body.cart != undefined) {
         const oldOrders = await user.findOne({ email: email });
         let newOrders = [];
         let modifiedOrders = [];
         req.body.cart.forEach((item) => {
            item.date = new Date();
            modifiedOrders.push(item);
         });
         console.log(modifiedOrders);
         if (oldOrders.orders.length > 0) {
            newOrders = [...oldOrders.orders, ...modifiedOrders];
         } else {
            newOrders = [...modifiedOrders];
         }
         console.log(newOrders);
         await user.updateOne(
            { email: email },
            {
               orders: newOrders,
            }
         );
         return res.status(200).send("placed order successfull");
      } else {
         return res.status(400).send("didn't got the cart");
      }
   } catch (error) {
      console.log(error);
      return res.status(500).send({
         message: "something bad happened",
      });
   }
};
