const Joi = require("joi");

const signUpSchema = Joi.object({
   username: Joi.string().trim().min(2).max(50).required(),
   email: Joi.string().email().trim().required(),
   password: Joi.string()
      .regex(
         /^(?=.*?[A-Z])(?=(.*[a-z]){1,})(?=(.*[\d]){1,})(?=(.*[\W]){1,})(?!.*\s).{8,}$/
      )
      .required(),
   contact: Joi.string().trim().min(10).max(10).required(),
   address: Joi.string().trim().min(10).max(80).required(),
});

const LoginSchema = Joi.object({
   email: Joi.string().email().trim().required(),
   password: Joi.string().required(),
});

module.exports = { signUpSchema, LoginSchema };
