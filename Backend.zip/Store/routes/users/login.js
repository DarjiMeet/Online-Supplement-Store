const argon = require("argon2");
const { generateJWT } = require("../../middlewares/auth");
const users = require("../../models/user");

module.exports = async (req, res, next) => {
   const { email, password } = req.body;

   let isAdmin = false;
   console.log(email);
   console.log(password);

   if (email === "admin@gmail.com" && password === "Admin@1234") {
      isAdmin = true;
      const JWT = generateJWT({
         email: email,
         isAdmin,
      });
      return res.status(200).send({
         message: "SUCCESS",
         token: JWT,
         isAdmin,
      });
   }

   const user = await users.findOne({
      email: (req.body.email + "").toLowerCase(),
   });

   if (user) {
      if (await argon.verify(user.password, req.body.password)) {
         const JWT = generateJWT({
            email: user.email,
            isAdmin,
         });

         return res.status(200).send({
            message: "SUCCESS",
            token: JWT,
            isAdmin,
         });
      } else {
         return res.status(400).send({
            message: "Incorrect Password",
         });
      }
   } else {
      return res.status(400).send({
         message: "User Not Exist...",
      });
   }
};
