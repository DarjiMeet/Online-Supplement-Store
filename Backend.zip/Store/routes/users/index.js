const signup = require("./signup");
const validator = require("../../middlewares/validation");
const { signUpSchema, LoginSchema } = require("./@validationSchema");
const login = require("./login");
const { authMiddlewareForLogin } = require("../../middlewares/auth");
const placeOrder = require("./placeOrder");
const getMyOrders = require("./getMyOrders");
const getEnitreDB = require("./getEnitreDB");

const router = require("express").Router({ mergeParams: true });

router.post("/signup", validator(signUpSchema), signup);
router.post("/login", validator(LoginSchema), login);
router.post("/order", authMiddlewareForLogin, placeOrder);
router.get("/order", authMiddlewareForLogin, getMyOrders);
router.get("/admin", authMiddlewareForLogin, getEnitreDB);

module.exports = router;
