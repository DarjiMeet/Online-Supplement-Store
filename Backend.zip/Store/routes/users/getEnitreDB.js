const users = require("../../models/user");

module.exports = async (req, res, next) => {
   const { isAdmin } = res.locals.decode;

   if (isAdmin) {
      try {
         const user = await users.find();
         return res.status(200).send(user);
      } catch (error) {
         console.log(error);
      }
   } else {
      return res.status(400).send({ message: "you are are not an admin" });
   }
};
