const argon = require("argon2");
const { ErrorHandler } = require("../../helpers/errors");
const constants = require("../../constants");
const users = require("../../models/user");
const { default: to } = require("await-to-js");

module.exports = async (req, res, next) => {
   var details = req.body;
   details.password = await argon.hash(details.password);
   details.email = (details.email + "").toLowerCase();

   try {
      const [err] = await to(users.create(details));

      if (err) {
         console.log(err);
         const error = new ErrorHandler(constants.ERRORS.DATABASE, {
            statusCode: 500,
            message: "user alreday exists",
            errStack: err,
         });

         return next(error);
      }
   } catch (err) {
      console.log(err);
      const error = new ErrorHandler(constants.ERRORS.UNEXPECTED, {
         statusCode: 500,
         message: "Server Error",
         errStack: err,
      });

      return next(error);
   }

   return res.status(200).send({
      message: "Signup Success",
   });
};
