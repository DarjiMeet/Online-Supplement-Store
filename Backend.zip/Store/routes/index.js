const router = require("express").Router({ mergeParams: true });
const product = require("./product");
const user = require("./users");

router.use("/product", product);
router.use("/user", user);

module.exports = router;
