const FilterReducer=(state,action)=>{
    switch(action.type){
        case "LOAD_FILTER_PRODUCTS":
            return{
                ...state,
                filter_products: action.payload,
                all_products: action.payload,
            }

        case "UPDATE_VLAUE":
            const {name,value}=action.payload
            return{
                ...state,
                filters:{
                    ...state.filters,
                    [name]:value
                }
            }

        case "FILTER_UPDATE":
            let {all_products}=state
            let temp = [...all_products]
            const {text,category}=state.filters
            if(text){
                temp=temp.filter((curr)=>{
                    return curr.name.toLowerCase().includes(text)
                })
            }
            
            if(category!=="All"){
                temp=temp.filter((curr)=>{
                    return curr.category===category
                })
            }
            

            return{
                ...state,
                filter_products: temp
            }


        default: return state
    }
}

export default FilterReducer