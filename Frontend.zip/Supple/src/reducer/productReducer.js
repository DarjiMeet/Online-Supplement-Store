const ProductReducer = (state, action) => {
    switch(action.type){
        case "SET_LOADING":
            return{
                ...state,
                isLoading:true
            }
    
        case "API_ERROR":
            return{
                ...state,
                isLoading:false,
                isError:true
            }
        case "MY_API_DATA":
           const typeproduct = action.payload.filter((currele)=>{
            return currele.type === "single"
           })
           const typeproduct2 = action.payload.filter((currele)=>{
            return currele.type === "offer"
           })
           const typeproduct3 = action.payload.filter((currele)=>{
            return currele.type === "combos"
           })
           return{
            ...state,
            isLoading:false,
            products: action.payload,
            producttype : typeproduct,
            productoffer: typeproduct2,
            productcombos: typeproduct3,
           }

           case "SINGLE_LOADING":
            return{
                ...state,
                isSingleLoading :true
            }

           case "SINGLE_API_DATA":
            return{
                ...state,
                isSingleLoading :false,
                singleProduct: action.payload
            }

           case "SINGLE_ERROR":
            return{
                ...state,
                isSingleLoading :false,
                isError:true
            }

        default:
            return state
    }

}

export default ProductReducer