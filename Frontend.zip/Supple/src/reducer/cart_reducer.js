import React from 'react'


const cart_reducer = (state,action) => {
  
  if(action.type==="ADD_TOCART"){
    let {id,amount,product}=action.payload
    // console.log(product)

    // existing product
    let existing = state.cart.find((curr)=>curr.id===id+product.weight)
    if(existing){
      let updateProduct = state.cart.map((curr)=>{
       if(curr.id===id+product.weight){
        let newamount=curr.amount+amount

        if(newamount>=curr.max){
          newamount=curr.max
        }

        return {
          ...curr,
          amount:newamount
        }
       }

       else{
        return curr
       }

      })
      return{
        ...state,
        cart:updateProduct
      }
    }

    else{
      
        let cartproduct;

        cartproduct={
            id: id+ product.weight,
            price: product.price,
            name: product.name,
            weight: product.weight,
            image: product.image[0].url,
            amount,
            max: product.stock
        }

        return{
          ...state,
          cart:[...state.cart,cartproduct]
      }
    }
  }

    
  


  if(action.type==="REMOVE_ITEM"){
    let updatecart=state.cart.filter((curr)=>{
      return curr.id!==action.payload
    })
    return {
      ...state,
      cart:updatecart
    }
  }


  if(action.type==="CLEAR_CART"){
    return{
      ...state,
      cart:[]
    }
  }


  if(action.type==="SET_DECREASE"){
    let updatedproduct = state.cart.map((curr)=>{
      if(curr.id===action.payload){
        let decamount = curr.amount-1
        if(decamount<=1){
          decamount = 1
        }
        return {
          ...curr,
          amount: decamount
        } 
      }
      else{
        return curr
      }
    })
    return {
      ...state,
      cart:updatedproduct
    }
  }


  if(action.type==="SET_INCREASE"){
    let updatedproduct = state.cart.map((curr)=>{
      if(curr.id===action.payload){
        let incamount = curr.amount+1
        if(incamount>=curr.max){
          incamount = curr.max
        }
        return {
          ...curr,
          amount: incamount
        } 
      }
      else{
        return curr
      }
    })
    return {
      ...state,
      cart:updatedproduct
    }
  }


  if(action.type==="CART_ITEM"){
    let updatecart = state.cart.reduce((accum,curr)=>{
      let {amount} = curr
      accum = accum+amount
      return accum
    },0)
    return {
      ...state,
      total_item:updatecart
    }
  }


  if(action.type==="CART_TOTAL"){
    let total_price = state.cart.reduce((accum,curr)=>{
      let {amount,price}=curr
      accum=accum+(price*amount)
      return accum
    },0)
    return{
      ...state,
      total_price: total_price
    }
  }


    return state
}

export default cart_reducer
