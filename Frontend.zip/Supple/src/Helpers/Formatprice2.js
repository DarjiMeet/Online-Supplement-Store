

const Formatprice2 = ({MRP}) => {
    return Intl.NumberFormat("en-IN",{
      style: 'currency', 
      currency: 'INR' ,
      minimumFractionDigits: 2,
     }).format(MRP/100);
    
  }
  
  export default Formatprice2
  