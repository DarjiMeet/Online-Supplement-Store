// create a context
// provider
// consumer => useContext Hook

import { createContext, useContext, useEffect, useReducer } from "react";
import axios from "axios"
import reducer from "../reducer/productReducer"
// crating a warehose to store data 
const Appcontext = createContext();
const API = "http://localhost:4000/product";

const initialSate ={
    isLoading: false,
    isError: false,
    products: [],
    producttype:[],
    productoffer:[],
    productcombos:[],
    isSingleLoading : false,
    singleProduct:{},
}
// create a provider
const Appprovider = ({children}) =>{
const [state,dispatch] = useReducer(reducer, initialSate);
    const getProducts= async (url)=>{
        dispatch({type: "SET_LOADING"})
        try {
            const res = await axios.get(url);
            const products = await res.data
            dispatch({type: "MY_API_DATA", payload: products})
        } catch (error) {
            dispatch({type: "API_ERROR"})
        }
    }

    //call for single products
    const getSingleProducts= async (url)=>{
        dispatch({type: "SINGLE_LOADING"})
        try{
            const res = await axios.get(url);
            const singleProducts2 = await res.data;
            dispatch({type: "SINGLE_API_DATA", payload: singleProducts2})
        }catch(error){
            dispatch({type: "SINGLE_ERROR"})
        }
    }





        useEffect(()=>{
            getProducts(API)
        },[]);
        return <Appcontext.Provider value={{...state,getSingleProducts}}>{children}</Appcontext.Provider>

}




//custom hook
const useProductContext = ()=>{
    return useContext(Appcontext)
}
export {Appprovider,Appcontext,useProductContext}