import { createContext, useContext, useEffect, useReducer } from "react";
import { useProductContext } from "./productcontext";
import reducer from "../reducer/filterReducer"
const Filtercontext = createContext()
const initialState={
    filter_products:[],
    all_products:[],
    filters:{
        text:"",
        category:"all",
    }
}

const Filtercontextprovider = ({children})=>{
   const {products} = useProductContext()
  
   const [state,dispatch]=useReducer(reducer,initialState)

   const updateVlaue=(event)=>{
    let name = event.target.name
    let value = event.target.value

    return dispatch({type:"UPDATE_VLAUE",payload:{name,value}})
   }

   useEffect(()=>{
    dispatch({type:"FILTER_UPDATE"})
   },[state.filters])

   useEffect(()=>{
    dispatch({type:"LOAD_FILTER_PRODUCTS",payload:products})
   },[products])

    return <Filtercontext.Provider value={{...state,updateVlaue}}>{children}</Filtercontext.Provider>
}

const useFiltercontext=()=>{
    return useContext(Filtercontext)
}

export {Filtercontextprovider,useFiltercontext,Filtercontext}