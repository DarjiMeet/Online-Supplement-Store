
import { createContext, useContext, useEffect, useReducer } from "react";
import reducer from "../reducer/cart_reducer"


const Cartcontext = createContext()

const getLocalCartData=()=>{
    
    let localCartData = localStorage.getItem("productCart")
    if (localCartData == 'undefined' || localCartData == null) return [];
    return JSON.parse(localCartData);

}


const initialSate={
    // cart:[],
    cart:getLocalCartData(),
    total_item:"",
    total_price:0,
    shipping_fees:5000
}

const Cartprovider=({children})=>{
    const [state,dispatch]=useReducer(reducer,initialSate)

    const remove=(id)=>{
        dispatch({type:"REMOVE_ITEM",payload:id})
    }
    const addtocart=(id,amount,product)=>{
        dispatch({type:"ADD_TOCART",payload:{id,amount,product}})
    }
    const clearCart=()=>{
        dispatch({type:"CLEAR_CART"})
    }
    const setDecrease = (id)=>{
        dispatch({type:"SET_DECREASE",payload:id})
    }
    const setIncrease = (id)=>{
        dispatch({type:"SET_INCREASE",payload:id})
    }

    useEffect(()=>{
        dispatch({type:"CART_ITEM"})
        dispatch({type:"CART_TOTAL"})
        localStorage.setItem("productCart",JSON.stringify(state.cart))
    },[state.cart])


    return <Cartcontext.Provider value={{...state,addtocart,remove,clearCart,setDecrease,setIncrease}}>{children}</Cartcontext.Provider>
}

const useCartcontext=()=>{
    return useContext(Cartcontext)
}

export {Cartprovider,useCartcontext}