import React from 'react'
import Header from './Header'
import Totalproducts from './Totalproducts'
import Productlist from './Productlist'
import Category from './Category'
import Search from './Search'

const Product = () => {
 
  return (
    <>
      <Header/>
      <div className='productcontainer'>
        
        <div className='filteritems'>
          <div className='search'>
            <Search/>
          </div>
          <div className='category'>
            <Category/>
          </div>
        </div>

        <div className='displayproducts'>
          <div className='totalproducts'>
            <Totalproducts/>
          </div>
          <div className='mainproduct'>
            <Productlist/>
          </div>
        </div>
      </div>
      {/* <div className='row productpage'>
        
          <ul className='col category'>
            <h4 className='HeadingCategory proheading'>Browse by Category</h4>
            <li className='categoryitem current'>All Products</li>
              <ul>
                <div className='proheading'>Sports Fuels</div>
              <li className='categoryitem nav-item'>All</li>
              <li className='categoryitem nav-item'>Whey Protein</li>
              <li className='categoryitem nav-item'>Creatine</li>
              <li className='categoryitem nav-item'>Pre-Workout</li>
              <li className='categoryitem nav-item'>BCAA</li>
              <li className='categoryitem nav-item'>EAA</li>
              </ul>
              <ul>
                <div className='proheading'>Health Fuel</div>
              <li className='categoryitem'>All</li>
              <li className='categoryitem'>Whey Protein</li>
              <li className='categoryitem'>Creatine</li>
              <li className='categoryitem'>Pre-Workout</li>
              <li className='categoryitem'>BCAA</li>
              <li className='categoryitem'>EAA</li>
              </ul>
              <ul>
                <div className='proheading'>Vitamins</div>
              <li className='categoryitem'>All</li>
              <li className='categoryitem'>Whey Protein</li>
              <li className='categoryitem'>Creatine</li>
              <li className='categoryitem'>Pre-Workout</li>
              <li className='categoryitem'>BCAA</li>
              <li className='categoryitem'>EAA</li>
              </ul>
              
            </ul>
          <div className='col productcontainer'>
           
          <span className='col product1'>
          <div class="col productitem"><Card image={MuscleBlaze} id={'MuscleBlaze'}/></div>
          <div class="col productitem"><Card image={GNC} id={'GNC'}/></div>
          <div class="col productitem"><Card image={DM} id={'dymatize'}/></div> 
          </span>
         
          <span className='col product2'>
          <div class="col productitem"><Card image={creatinMB2} id={'creatinMB2'}/></div>
          <div class="col productitem"><Card image={GNC} id={'GNC'}/></div>
          <div class="col productitem"><Card image={DM} id={'dymatize'}/></div> 
          </span>

          <span className='col product3'>
          <div class="col productitem"><Card image={MuscleBlaze} id={'MuscleBlaze'}/></div>
          <div class="col productitem"><Card image={GNC} id={'GNC'}/></div>
          <div class="col productitem"><Card image={DM} id={'dymatize'}/></div> 
          </span>
          
          </div>
          <div className='col productcontainer'>
          <span className='col product1'>
          <div class="col productitem"><Card image={MuscleBlaze} id={'MuscleBlaze'}/></div>
          <div class="col productitem"><Card image={GNC} id={'GNC'}/></div>
          <div class="col productitem"><Card image={DM} id={'dymatize'}/></div> 
          </span>
         
          <span className='col product2'>
          <div class="col productitem"><Card image={MuscleBlaze} id={'MuscleBlaze'}/></div>
          <div class="col productitem"><Card image={GNC} id={'GNC'}/></div>
          <div class="col productitem"><Card image={DM} id={'dymatize'}/></div> 
          </span>
          <span className='col product3'>
          <div class="col productitem"><Card image={MuscleBlaze} id={'MuscleBlaze'}/></div>
          <div class="col productitem"><Card image={GNC} id={'GNC'}/></div>
          <div class="col productitem"><Card image={DM} id={'dymatize'}/></div> 
          </span>
          
          </div>
          <div className='col productcontainer'>
          <span className='col product1'>
          <div class="col productitem"><Card image={MuscleBlaze} id={'MuscleBlaze'}/></div>
          <div class="col productitem"><Card image={GNC} id={'GNC'}/></div>
          <div class="col productitem"><Card image={DM} id={'dymatize'}/></div> 
          </span>
         
          <span className='col product2'>
          <div class="col productitem"><Card image={MuscleBlaze} id={'MuscleBlaze'}/></div> 
          <div class="col productitem"><Card image={GNC} id={'GNC'}/></div>
          <div class="col productitem"><Card image={DM} id={'dymatize'}/></div> 
          </span>
          <span className='col product3'>
          <div class="col productitem"><Card image={MuscleBlaze} id={'MuscleBlaze'}/></div>
          <div class="col productitem"><Card image={GNC} id={'GNC'}/></div>
          <div class="col productitem"><Card image={DM} id={'dymatize'}/></div> 
          </span>
          
          </div>
          <div className='col productcontainer'>
          <span className='col product1'>
          <div class="col productitem"><Card image={MuscleBlaze} id={'MuscleBlaze'}/></div>
          <div class="col productitem"><Card image={GNC} id={'GNC'}/></div>
          <div class="col productitem"><Card image={DM} id={'dymatize'}/></div> 
          </span>
         
          <span className='col product2'>
          <div class="col productitem"><Card image={MuscleBlaze} id={'MuscleBlaze'}/></div> 
          <div class="col productitem"><Card image={GNC} id={'GNC'}/></div>
          <div class="col productitem"><Card image={DM} id={'dymatize'}/></div> 
          </span>
          <span className='col product3'>
          <div class="col productitem"><Card image={MuscleBlaze} id={'MuscleBlaze'}/></div>
          <div class="col productitem"><Card image={GNC} id={'GNC'}/></div>
          <div class="col productitem"><Card image={DM} id={'dymatize'}/></div> 
          </span>
          
          </div>
        </div>
        <nav aria-label="Page navigation example">
          <ul class="pagination justify-content-center">
          
            <li class="page-item"><a class="page-link" href="#">1</a></li>
            <li class="page-item"><a class="page-link" href="#">2</a></li>
            <li class="page-item"><a class="page-link" href="#">3</a></li>

          </ul>
        </nav> */}
    </>
  )
}

export default Product
