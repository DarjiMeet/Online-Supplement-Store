import axios from 'axios';
import React, { useEffect, useState } from 'react'
import Historyitems from './Historyitems';
import Header from './Header'

const ORederhistory = () => {
    const URL = "http://localhost:4000/user/order";
    const [data, setData]=useState([])
    useEffect(()=>{
        loaddata()
    }, []);
   
    const loaddata= async()=>{
    
      try {
          const res = await axios.get(URL, {
              headers: {
                'Authorization':`Bearer ${localStorage.getItem("Signin")}` 
              }
          })
          setData(res.data)

        //   alert("place order successfully")
        //   // localStorage.setItem("productCart",JSON.stringify([]))
        //   clearCart()
        //   navigate("/");
      } catch (error) {
          alert("Something went wrong")
          console.log(error)
      }
     
    }
  return (

    <div className='historydata'>
        <Header/>
        <h3 style={{marginTop:30+"px",textAlign:"center"}}>Recent Orders</h3>
        <div className='usergrid' style={{marginTop:20+"px"}}>
            <div>Product</div>
            <div>Name</div>
            <div>Qauntity</div>
            <div>Price</div>
            <div>Weight</div>
            <div>Date</div>
        </div>
        <hr className='hr'/>
        {data.map((curr,index)=>{
            if (index == 0) return;
            return  <Historyitems key={curr.id} {...curr}/>
        })}
       
    </div>
  )
}

export default ORederhistory
