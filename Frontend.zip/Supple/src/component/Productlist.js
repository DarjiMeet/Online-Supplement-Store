import React from 'react'
import { useFiltercontext } from '../context/filtercontext'
import Gridview from './Gridview';
const Productlist = () => {
  const {filter_products}=useFiltercontext();

  return (
    < div className='productlist'>
      <Gridview products={filter_products}/>
    </div>
  )
}

export default Productlist
