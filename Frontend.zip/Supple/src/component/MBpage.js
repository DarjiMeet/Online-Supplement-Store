import React from 'react'
import { useFiltercontext } from '../context/filtercontext'
import Header from './Header'
import Products from './products'

const MBpage = () => {
    const {all_products}=useFiltercontext()
    const products = all_products.filter((curr)=>{
        return curr.company==="MuscleBlaze"
    })
  return (
    <>
      <Header/>
      <div className='offertab'>
        {products.map((curr)=>{
            return <Products key={curr.id} {...curr} />
        })}
      </div>
    </>
  )
}

export default MBpage
