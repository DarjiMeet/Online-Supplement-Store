import axios from 'axios';
import React,{useState} from 'react'
import { NavLink, useNavigate } from 'react-router-dom'

const Signin = () => {
    const [email, setEmail] = useState("");
    const [password, setpassword] = useState("");
    const navigate=useNavigate()

  const URL = "http://localhost:4000/user/login";
  const Onsign= async(event)=>{
    event.preventDefault();
    try {
        const res = await axios.post(URL,{
            email: email,
            password:password,
        }, {
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded'
            }
        })
        console.log(res.data)
        localStorage.setItem("Signin",res.data.token)
        alert("SignIn successful")
        navigate("/")
    } catch (error) {
        
    }
  }
  return (
    <div className='contactform'>
      <div className='contactus'>
        <form method='POST' action='' className='contactitem'>
            <h2 style={{textAlign:"center"}}>Sign In</h2>
           
            <input type='email' className='email' placeholder='Email' value={email} onChange={(event)=>setEmail(event.target.value)}/>
            <input type='text' className='password' placeholder='Password' value={password} onChange={(event)=>setpassword(event.target.value)}/>
            <div className='signin'>
            <button className='btn-secondary btnsign' onClick={Onsign}>Sign In</button>
            <NavLink to="/Signup" className="nav-link">Sign Up</NavLink>
           </div>
            
        </form>
       
      </div>
    </div>
  )
}

export default Signin