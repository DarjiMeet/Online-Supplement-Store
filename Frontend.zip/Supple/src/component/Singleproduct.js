import React, { useEffect } from 'react'
import Header from './Header'
import { useParams } from 'react-router-dom'
import { useProductContext } from '../context/productcontext';
import Myimage from './Myimage';
import Formatprice from '../Helpers/Formatprice';
import Formatprice2 from '../Helpers/Formatprice2';
import Stars from './Stars';
import Addtocart from './Addtocart';

const API = "http://localhost:4000/product";
const Singleproduct = () => {
    const { getSingleProducts, isSingleLoading,singleProduct} = useProductContext();
    
    const {id}=useParams();
  
    const{
        id:alias,
        name,
        company,
        price,
        MRP,
        weight,
        flavour,
        discription,
        stock,
        category,
        star,
        review,
        display,
        image
    }=singleProduct


    useEffect(()=>{
        getSingleProducts(`${API}/${id}`)
    },[])

    if(isSingleLoading){
        return <div>Loading....</div>
    }

  return (
    <>
        <Header/>
       
      <div className='singlepage'>
        <div className='singlegrid' >
            <div className='myimages'><Myimage img={image}/></div>
            <div className=' data'>
                <h2 className='singleheading'>{name}</h2>
                <div className='stars'><Stars star={star} reviews={review}/></div>
               <p className='dataprice'>
                    <span className='MRP' style={{textDecoration:"line-through",paddingLeft:0}}>{<Formatprice2 MRP={MRP}/>}</span>
                    <span className='price' style={{fontWeight:"bold",paddingLeft:10+"px"}}>{<Formatprice price={price}/>}</span>
                </p>
                <div className='Infodata'>
                    <p className='weight' >Weight: <span style={{fontWeight:500}}>{weight}</span></p>
                    <p className='flavour'>Flavour: <span style={{fontWeight:500}}>{flavour}</span></p>
                </div>

                <div className='discription'>
                    <h5>Product Information</h5>
                    <p>{discription}</p>
                </div>
                <div className='stock'>Available: <span style={{fontWeight:500}}>{stock>0?"In Stock":"Out Of Stock"}</span></div>
                <div className='company'>Brand: <span style={{fontWeight:500}}>{company}</span></div>
                <hr/>
                <Addtocart product={singleProduct}/>
            </div>
        </div>
      </div>
    </>
  )
}

export default Singleproduct
