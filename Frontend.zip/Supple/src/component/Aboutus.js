import React from 'react'
import Aboutimage1 from './Aboutimage1.png'
function About(){
    return <>
        <div className='about'>
        <div className='companyintro'>
        <h2 className='Intro'>We're FLEX|FUEL- a great place for people serious about health and fitness</h2>
        <div className='Intropara'>We're a young start-up that work for your needs in fitness and well-being. We deliver everything from genuine protein supplements to vitamins smoothly at honest prices.
        </div>
        <button className='learnmore'>Learn More</button>
        </div>
        <div ><img src='https://static1.hkrtcdn.com/mbnext/static/media/aboutUs/img1.png' alt='image1' style={{width:450+"px"}}/></div>
        </div>
    </>
}

export default About;