import React from 'react'


function Brands(props){
    return <img src={props.image} id={props.id} className='logoimage'/>
}

export default Brands;