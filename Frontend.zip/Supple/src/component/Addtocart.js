import React, { useState } from 'react'
import CartAmount from './CartAmount';
import { NavLink } from 'react-router-dom';
import { useCartcontext } from '../context/cart_context';


const Addtocart = ({product}) => {
  const {addtocart}=useCartcontext()
    const {id,stock}=product
    const [amount,setamount]=useState(1);

    const setDecrease = ()=>{
        amount>1?setamount(amount-1):setamount(1)
    }
    const setIncrease = ()=>{
        amount<stock?setamount(amount+1):setamount(stock)
    }
  return (
<>  
    <div className='addtocart'>
      <CartAmount 
        amount={amount}
        setDecrease={setDecrease}
        setIncrease={setIncrease}
      />
    </div>
    <NavLink to="/cart" className="nav-link"  onClick={()=>{addtocart(id,amount,product)}}>
    <button type="button" class="btn btn-dark">Add To Cart</button>
    </NavLink>
</>
  )
}
 
export default Addtocart
