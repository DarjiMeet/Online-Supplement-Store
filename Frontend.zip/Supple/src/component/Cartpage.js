import React from 'react'
import { useCartcontext } from '../context/cart_context'
import Header from './Header'
import Cartitems from './Cartitems'
import { NavLink, useNavigate } from 'react-router-dom'
import Formatprice from '../Helpers/Formatprice'
import axios from 'axios'


const Cartpage = () => {
    const {cart,clearCart,total_price,shipping_fees}=useCartcontext()
    const URL = "http://localhost:4000/user/order";
    const navigate = useNavigate()
    const onbuy= async(event)=>{
      event.preventDefault();
      try {
          const res = await axios.post(URL,{
              cart
          }, {
              headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Authorization':`Bearer ${localStorage.getItem("Signin")}` 
              }
          })

          alert("place order successfully")
          // localStorage.setItem("productCart",JSON.stringify([]))
          clearCart()
          navigate("/");
      } catch (error) {
          alert("Something went wrong")
          console.log(error)
      }
     
    }

    if(cart===null || cart.length===0){
      return <div className='emptycart'>
        <Header/>
        <div className='empyt text' style={{fontSize:20+"px",color:"grey",textAlign:"center"}}> Your cart is empty</div>
       
      </div>
    }
    else{
      return (
        <div className='cartpage'>
            <Header/>
          <div className='colhead'>
            <p>Item</p>
            <p>Price</p>
            <p>Qauntity</p>
            <p>SubTotal</p>
            <p>Remove</p>
          </div>
          <hr className='hr'/>
          <div className='items'>
            {cart.map((curr)=>{
                return <Cartitems key={curr.id} {...curr}/>
            })}
          </div>
          <hr className='hr'/>
          <div className='twobtn'>
            <NavLink to="/products" className="nav-link">
              <button type="button" class="btn btn-secondary Continue ">Continue Shopping</button>
            </NavLink>
            <button type="button" class="btn btn-info Continue " onClick={onbuy}>Buy Now</button>
            <div style={{alignContent:"center"}}>
              <button type="button" class="btn btn-dark Clear " onClick={clearCart}>Clear Cart</button>
            </div>
          </div>
          <div className='cartdiv'>
            <div className='carttotal'>
              <p>SubTotal:</p>
              <p><Formatprice price={total_price}/></p>
              <p>Shipping Fees:</p>
              <p><Formatprice price={shipping_fees}/></p>
              <hr className='hrgrid'/>
              <p>Order Total:</p>
              <p><Formatprice price={total_price+shipping_fees}/></p>
            </div>
          </div>
          
        </div>
      )
    }
  }
  
   
 

export default Cartpage
