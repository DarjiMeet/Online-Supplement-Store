import React from 'react'
import CartAmount from './CartAmount'
import { ImBin2 } from "react-icons/im";
import Formatprice from '../Helpers/Formatprice';
import { useCartcontext} from '../context/cart_context';


const Cartitems = ({id,price,name,weight,amount,image,max}) => {
  const{remove,setIncrease,setDecrease}=useCartcontext()
    
  return (
    <div className='cartitems'>
      <div className='image-name'>
        <div>
            <img src={image} alt={id} style={{width:100+"px"}}/>
        </div>
        <div>
            <div style={{paddingTop:5+"px"}}>{name}</div>
           <div style={{paddingTop:3+"px"}}>{weight}</div>
        </div>
      </div>
      <div className='price'>
        <Formatprice price={price}/>
      </div>
     <div className='quantity'> 
     <CartAmount 
        amount={amount}
        setDecrease={()=>setDecrease(id)}
        setIncrease={()=>setIncrease(id)}
        />
        </div>
        <div className='subtotal'>
            <Formatprice price={price*amount}/>
        </div>
       <div className='delete'>
            <ImBin2 className='removeitem' onClick={()=>remove(id)}/>
        </div> 
    </div>
  )
}

export default Cartitems
