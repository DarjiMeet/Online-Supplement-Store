import React from 'react'
import Header from './Header'

const Contactpage = () => {
  return (
    <div className='Contactpage'>
      <Header/>
      <div className='contactform'>
        <div className='contactus'>
            <form action='https://formspree.io/f/mjvnjzwl' method='POST' className='contactitem'>
                <h3>Contact Us</h3>
                <div className='contactmessage' >Feel free to contact us for any query</div>
                <input type='text' placeholder='username' name='username' required autoComplete='off' />
                <input type='email' placeholder='useremail' name='useremail' required autoComplete='off'/>
                <textarea name='message' cols="30" rows="10" required autoComplete='off' placeholder='Enter your message'></textarea>
                <input type='submit' value="send" style={{width:100+"px",backgroundColor:"rgb(92 173 227)" , border:"none" ,borderRadius:10+"px",cursor:"pointer"}}/>
            </form>
        </div>
      </div>
    </div>
  )
}

export default Contactpage
