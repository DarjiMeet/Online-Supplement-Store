import React from 'react'
import { useFiltercontext } from '../context/filtercontext'

 
const Category = () => {
  const {all_products,updateVlaue,filters:{category},filter_products}=useFiltercontext()

  const getCategoryData=(data,property)=>{
    let newval=data.map((curr)=>{
      return curr[property];
    })
   
   return (newval=["All",...new Set(newval)])
    
  }
  const getCompanyData=(data,property)=>{
    let newval=data.map((curr)=>{
      return curr[property];
    })
    console.log(newval)
   return (newval=["All",...new Set(newval)]) 
  }

  const categoryData=getCategoryData(all_products,"category")
  const companyData=getCompanyData(all_products,"company")
 

  return (
    <div className='List'>
      <h5>Category</h5>
      <div className='categorylist'>
        {categoryData.map((curr,index)=>{
          return <div className='categorybutton'><button key={index} type='button' name='category' value={curr} onClick={updateVlaue} className='listitem'>{curr}</button></div>
        })}
      </div>
     
    </div>
  )
}

export  default  Category
