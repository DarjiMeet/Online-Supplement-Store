import React from 'react'
import Header from './Header'
import Products from './products'
import { useFiltercontext } from '../context/filtercontext'

function Offertab(){
  const {all_products}=useFiltercontext()
  const onclick=()=>{
     let value= all_products.filter((curr)=>{
        return curr.extra==="offer"
      })
     console.log(value)
     return value
    }
  const getonclickdata = onclick()
  return (
    <>
    <Header/>
      <div className='offertab'>
        {getonclickdata.map((curr)=>{
         return <Products key={curr.id} {...curr} />
        })}
      </div>
    </>
  )
}

export default Offertab
