import React from 'react'
import Header from './Header'
import MBLogo from "./MBLogo.webp"
import AtomLogo from "./AtomLogo.webp"
import ONLogo from "./ONLogo.webp"
import HFLogo from "./HFLogo.webp"
const Aboutpage = () => {
  return (
    <div className='Aboutpage'>
      <Header/>
      <div className='aboutpagesection'>
        <div className='rows'>
            <div className='coloumn1' style={{width:40+"vw"}}>
                <p className='hello'>Hello!</p>
                <p className='introtext'>We're FLEX|FUEL a great place for people serious about health and fitness.</p>
                <p className='intromessage'>We're a young start-up of around 400 people that work for your needs in fitness and well-being. We deliver everything from genuine protein supplements to Healthy Snack smoothly at honest prices.</p>
            </div>
            <div className='coloumn2'><img src='https://static1.hkrtcdn.com/mbnext/static/media/aboutUs/img1.png' alt='image1' style={{width:450+"px"}}/></div>
        </div>
        <div className='rows row2'>
            <div className='coloumn1 coloumn3'>
                <img src='https://static1.hkrtcdn.com/hknext/static/media/aboutUs/authenticity-about.webp' alt='image1' style={{width:200+"px"}}/>
                
                </div>
                <div className='coloumn2 coloumn4' style={{width:40+"vw"}}>
                        <p className='introtext'>We do what's right by you. We value authenticity over everything else.</p>
                        <p className='intromessage'>We sell consumables that you need rather than want. In such cases, the authenticity of the product matters. Half the supplement market is flooded with fakes pumped with steroids. And that's why when you shop whey from us, be sure it is 100% genuine, without any junk.</p>
                        <p className='intromessage'>Whenever you see this logo next to our product, it's just our way of telling you that we've sourced the product directly and test it before sending it out to you. It is to tell you that what you are having is safe.
                        </p>
                </div>
        </div>
        <div className='rows row3'>
                <div className='coloumn2 coloumn6' style={{width:40+"vw"}}>
                        <p className='introtext'>Good health delivered to your doorstep, every time</p>
                        <p className='intromessage'>You no longer have to hunt for your supplements or a ton of nutrition stores to find the supplement you need. We have the best 4 Brands & authorized vendors listed on our website. All just to make sure what you get is right.</p>
                </div>
                <div className='coloumn1 coloumn5'>
                    <img src={MBLogo} alt='image1' style={{width:80+"px"}}/>
                    <img src={HFLogo} alt='image1' style={{width:145+"px"}}/>
                    <img src={ONLogo} alt='image1' style={{width:115+"px"}}/>
                    <img src={AtomLogo} alt='image1' style={{width:150+"px"}}/>
                
                </div>
        </div>
        <div className='rows row4'>
                <div className='coloumn1 coloumn7'>
                    <img src="https://static1.hkrtcdn.com/hknext/static/media/aboutUs/press.webp" alt='image1' style={{width:25+"vw"}}/>
                
                </div>
                <div className='coloumn2 coloumn8' style={{width:40+"vw"}}>
                        <p className='introtext'>Good health delivered to your doorstep, every time</p>
                        <p className='intromessage'>You no longer have to hunt for your supplements or a ton of nutrition stores to find the supplement you need. We have the best 4 Brands & authorized vendors listed on our website. All just to make sure what you get is right.</p>
                </div>
        </div>
      </div>
    </div>
  )
}

export default Aboutpage
