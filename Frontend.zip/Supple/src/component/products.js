import React from 'react'
import { NavLink } from 'react-router-dom';
import Formatprice from '../Helpers/Formatprice';
import Formatprice2 from '../Helpers/Formatprice2';
const Products = (curr) => {
    const {id,name,price,category,image,MRP}=curr;
  return (
    <NavLink to={`/singleproduct/${id}`} className="nav-link">
        <div className=" productcard" style={{width: 20+"rem", textAlign: "center"}}>
                <img src={image} classname="card-img-top" style={{width: 200+"px"}} alt={name}/>
                <div classname="card-body">
                    <div classname="card-text">
                        <div className='name'>{name}</div>
                        <div className='displayflex'>
                        <div className='price'>{<Formatprice price={price}/>}</div>
                        <div className='MRP'>{<Formatprice2 MRP={MRP}/>}</div>
                        </div>
                    </div>
                </div>
            </div>
    </NavLink>
   
  )
}

export default Products
