import React from 'react'
import Products from './products'
const Gridview = ({products}) => {
  return (
    <div className='gridview'>
      {
        products.map((curr)=>{
            return <Products key={curr.id} {...curr}/>
        })
      }
    </div>
  )
}

export default Gridview
