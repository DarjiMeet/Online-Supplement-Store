import React from 'react'
import { useFiltercontext } from '../context/filtercontext'
const Totalproducts = () => {
  const {filter_products}=useFiltercontext()
  const Length=filter_products.length
  return (
    <div className='totalproducts' style={{textAlign:"center",paddingBottom:10+"px"}}>
      {Length} Products
    </div>
  )
}

export default Totalproducts
