import React from 'react'


function Offers(props){
    return <img src={props.image}/>
}

export default Offers;