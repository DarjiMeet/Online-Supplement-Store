import {useProductContext} from '../context/productcontext';
import Products from './products';

const Producttype = () => {
    const {isLoading,producttype,productoffer,productcombos} = useProductContext()
    // console.log("producttype=single",producttype)
    // console.log("producttype=offer",productoffer)
    // console.log("producttype=combos",productcombos)
    if(isLoading){
        return <div>.......Loading</div>
    }
  return (
    
    <div className='section'>
        <div className='contained'>
        <h3 className='intro-data'>Best Selling Products!</h3>
            <div className='grid'>
                {
                    producttype.map((curr)=>{
                        return <Products key={curr.id} {...curr}/>
                    })
                }
            </div>
            
        </div>
        <div className='contained'>
        <h3 className='intro-data'>Special Offers!</h3>
            <div className='grid'>
                {
                    productoffer.map((curr)=>{
                        return <Products key={curr.id} {...curr}/>
                    })
                }
            </div>
            
        </div>
        <div className='contained'>
        <h3 className='intro-data'>Combos Deals!</h3>
            <div className='grid'>
                {
                    productcombos.map((curr)=>{
                        return <Products key={curr.id} {...curr}/>
                    })
                }
            </div>
            
        </div>
    </div>
  
  )
}

export default Producttype
