import React from 'react'
import Header from './Header';
import Home from './Home'
import {BrowserRouter as Router, Routes,Route,Link} from "react-router-dom"
import Offertab from './Offertab';
import Product from './Product';
import Blog from './Blog';
import Singleproduct from './Singleproduct';
import Cartpage from './Cartpage';
import Aboutpage from './Aboutpage';
import Contactpage from './Contactpage';
import MBpage from './MBpage';
import ONpage from './ONpage';
import HFpage from './HFpage';
import Dympage from './Dympage';
import Signup from './Signup';
import Signin from './Signin';
import ORederhistory from './ORederhistory';

function App(){
    return <Router>
    <div className='main'>
      <Routes>
          <Route path="/" element={<Home />}/>
          <Route path="/signup" element={<Signup />}/>
          <Route path="/signin" element={<Signin />}/>
          <Route path="/blogs" element={<Blog />} />
          <Route path="/About" element={<Aboutpage />} />
          <Route path="/Contact" element={<Contactpage />} />
          <Route path="/offers" element={<Offertab />} />
          <Route path="/products" element={<Product />}/>
         <Route path='/singleproduct/:id' element={<Singleproduct/>}/>
         <Route path="/cart" element={<Cartpage/>}/>
         <Route path="/MBitems" element={<MBpage/>}/>
         <Route path="/ONitems" element={<ONpage/>}/>
         <Route path="/HFitems" element={<HFpage/>}/>
         <Route path="/Dymitems" element={<Dympage/>}/>
         <Route path="/orderhistory" element={<ORederhistory/>}/>


      </Routes>
      </div>
    </Router>
    
}

export default App;