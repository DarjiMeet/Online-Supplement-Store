import React, { useEffect, useState } from 'react'
import MBLogo from "./MBLogo.webp"

import ONLogo from "./ONLogo.webp"

import HFLogo from "./HFLogo.webp"
import { FiShoppingCart } from "react-icons/fi";
import DymatizeLogo from "./DymatizeLogo.webp"
import LOGO from "./LOGO.png"

import {Link, NavLink, useNavigate} from "react-router-dom"
import { useCartcontext } from '../context/cart_context';


function Header(){
    const {total_item,clearCart}=useCartcontext()
    const [token,setToken]=useState()
    const navigate = useNavigate()
    useEffect(()=>{
        if(localStorage.getItem("Signin")){
            setToken("Sign Out")
        }
        else{
            setToken("Sign Up")
        }
    },[])

    const Onclick = ()=>{
        if(token==="Sign Out"){
            localStorage.removeItem("Signin")
            clearCart()
            setToken("Sign Up")
        }
        else{
            navigate("/signup")
        }
    }

    
    return <>
        <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
            <Link class="navbar-brand" to="/"><img src={LOGO} alt='logo' className='logo'/></Link>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item dropdown">
                <Link class="nav-link" to="/products" role="button" >
                    Products
                </Link>
                
                </li>
                <li class="nav-item">
                <Link class="nav-link" to="/offers">Offers</Link>
                </li>
                <li class="nav-item">
                <Link class="nav-link" to="/About">AboutUs</Link>
                </li>
                <li class="nav-item">
                <Link class="nav-link" to="/Contact">ContactUs</Link>
                </li>
                <li class="nav-item">
                <Link class="nav-link" to="/blogs">Blogs</Link>
                </li>
                <li class="nav-item dropdown">
                <Link class="nav-link dropdown-toggle dropdowns"  role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Brands
                </Link>
                <ul class="dropdown-menu">
                    <div className='row'>
                    <li className='col collogo'><Link class="dropdown-item" to="/MBitems"><img src={MBLogo} className='logos'/></Link></li>
                    <li className='col collogo'><Link class="dropdown-item" to="/ONitems"><img src={ONLogo} className='logos'/></Link></li>
                    </div>

                    <div className='row'>
                    <li className='col collogo'><Link class="dropdown-item" to="/Dymitems"><img src={DymatizeLogo} className='logos'/></Link></li>
                    <li className='col collogo'><Link class="dropdown-item" to="/HFitems"><img src={HFLogo} className='logos'/></Link></li>
                    </div>
                    
                </ul>
                </li>
  
            </ul>
            <NavLink to="/orderhistory" className="nav-link">
                <div className='orderhistory'>
                    Order History
                </div>
            </NavLink>
            <NavLink to="/cart" className="nav-link">
                <div className='carticon'>
                <FiShoppingCart />
                <span className='iconnumbers'>{total_item}</span>
                </div>
            </NavLink>

            <NavLink to="/signup" className="nav-link">
            <form class="d-flex" role="search">
                <button class="btn login" type="submit" onClick={Onclick}>{token}</button>
            </form>
            </NavLink>
            
            
            </div>
        </div>
        </nav>
       
    </>
}

export default Header;