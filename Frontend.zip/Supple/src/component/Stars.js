import React from 'react'
import { FaStar } from "react-icons/fa6";
import { FaRegStarHalfStroke } from "react-icons/fa6";
import { FaRegStar } from "react-icons/fa6";

const Stars = ({star,reviews}) => {
    const ratingstar = Array.from({length:5}, (elem,index)=>{
        let number = index+0.5

        return (
            <span key={index}>
                {
                    star >= index+1 ? (<FaStar className='icon'/>) : star >= number ? (<FaRegStarHalfStroke className='icon'/>): (<FaRegStar className='icon'/>)
                }
            </span>
        )
    })
  return (
    <div className='iconstyle'>
      <p className='star'> {ratingstar}</p>
      <p className='review'> ({reviews} customer reviews)</p>
    </div>
  )
}

export default Stars
