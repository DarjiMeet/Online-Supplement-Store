import React, { useState } from 'react'

const Myimage = ({img=[{url:""}]}) => {
    const[count,setCount]=useState(0)

  return (
    <div className='imagegrid'>
      <div className='imagecol'>
        {img!==undefined?
        img.map((curr,index)=>{
            return(
                <img 
                    src={curr.url} 
                    alt={curr.id}
                    key={index}
                    style={{width: 100+"px"}}
                   onClick={()=>{setCount(index)}}
                />
            )
            }):null
        }
      </div>
      <div className='mainimage'><img src={img[count].url} alt={img[count].id} style={{width:480+"px"}}/></div>
    </div>
 
  )
}

export default Myimage
