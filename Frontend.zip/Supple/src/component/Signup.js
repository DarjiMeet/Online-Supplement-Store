import axios from 'axios'
import React, { useState } from 'react'
import { NavLink, useNavigate } from 'react-router-dom'

const Signup = () => {
    const [email, setEmail] = useState("");
    const [username, setUsername] = useState("");
    const [password, setpassword] = useState("");
    const [contact, setContact] = useState("");
    const [address, setAddress] = useState("");
    const URL = "http://localhost:4000/user/signup";
    const navigate = useNavigate();

    const Onsign=async(event)=>{
        event.preventDefault();
        try {
            const res = await axios.post(URL,{
                email: email,
                password:password,
                contact:contact,
                address:address,
                username:username
            }, {
                headers: {
                  'Content-Type': 'application/x-www-form-urlencoded'
                }
            })
            alert("Signup successful")
            navigate("/signin");
        } catch (error) {
            alert("Something went wrong, please check your email and password")
            console.log(error)
        }
       
    }
  return (
    <div className='contactform'>
      <div className='contactus'>
        <form method='POST' className='contactitem'>
            <h2 style={{textAlign:"center"}}>Sign Up</h2>
            <input type='text' className='usename' placeholder='Username' value={username} onChange={(event)=>setUsername(event.target.value)}/>
            <input type='number' className='usename' placeholder='Phone Number' value={contact} onChange={(event)=>setContact(event.target.value)}/>
            <input type='email' className='email' value={email} placeholder='Email'onChange={(event) => setEmail(event.target.value)}/>
            <input type='text' className='password' value={password} placeholder='Password' onChange={(event)=>setpassword(event.target.value)}/>
            <textarea name='address' value={address} cols="5" rows="5" required autoComplete='off' placeholder='Enter your Address' onChange={(event)=>setAddress(event.target.value)}></textarea>
            <div className='signin'>
            <button className='btn-secondary btnsign' onClick={Onsign}>Sign Up</button>
            <NavLink to="/Signin" className="nav-link">Sign In</NavLink>
           </div>
        </form>
       
      </div>
    </div>
  )
}

export default Signup
