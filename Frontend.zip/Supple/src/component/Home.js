import React, { useState } from 'react'
import Slider from './slider';
// import Proteinsnack from './proteinsnack';
// import Card from './Card';
// import MuscleBlaze from './MuscleBlaze.png'
// import DM from './DM.avif'
// import GNC from './GNC.png'
// import FO from './FO.png'
// import MT from "./MT.png"
// import HF from "./HF.png"
// import AT from "./AT.png"
// import Mp from "./Mp.png"
// import On from "./On.png"
import nextimage from "./nextimage.png"
import previousimage from "./previousimage.png"
// import Offers from './Offer';
// import offer1 from './offer1.webp'
// import offer2 from './offer2.webp'
// import offer3 from './offer3.webp'
// import offer4 from './offer4.webp'
// import Vitamins from './vitamins';
import About from './Aboutus';
import Brands from './brands';
import MBLogo from "./MBLogo.webp"

import ONLogo from "./ONLogo.webp"

import HFLogo from "./HFLogo.webp"

import DymatizeLogo from "./DymatizeLogo.webp"

import Header from './Header';
import Producttype from './producttype';





function Home(){
   
    return<section className='Homecontainer'>
    
        <Header/>
        <Slider/>
        {/* <h1 className="text-center offer">Exclusive Offers</h1>
        <div className='row exclusive'>
        <div className='col offeritems'><Offers image={offer1}/></div>
        <div className='col offeritems'><Offers image={offer2}/></div>
        <div className='col offeritems'><Offers image={offer3}/></div>
        <div className='col offeritems'><Offers image={offer4}/></div>
        </div>
        <div className='sports'>
        <h1 class="text-center protitle">Sports Fuel</h1>
        
        </div>
        {next===0?<><div class="row Homeproduct Homeproduct1">
        <div class="col"><Card image={MuscleBlaze} id={'MuscleBlaze'}/></div>
        <div class="col"><Card image={GNC} id={'GNC'}/></div>
        <div class="col"><Card image={DM} id={'dymatize'}/></div> 
        <div class="col"><Card image={FO} id={'Feulone'}/></div>
        </div>
        <div className='controller'>
        <div className='empty'></div>
        <div className='circles'>
        <div className='circle1'  style={{backgroundColor: " rgb(92, 173, 227)"}}></div>
        <div className='circle2'></div>
        </div>
        <img src={nextimage} onClick={onClick1} className='nextimage'/>
        </div></>:null}

        {next===1?<><div class="row Homeproduct Homeproduct2">
        <div class="col"><Card image={HF} id={'Healthfarm'}/></div>
        <div class="col"><Card image={AT} id={'Atom'}/></div>
        <div class="col"><Card image={Mp} id={'Myprotein'}/></div> 
        <div class="col"><Card image={MT} id={'muscletech'}/></div>
        </div>        
        <div className='controller'>
        <img src={previousimage} onClick={onClick2} className='nextimage'/>
        <div className='circles'>
        <div className='circle1'></div>
        <div className='circle2'  style={{backgroundColor: " rgb(92, 173, 227)"}}></div>
        </div>
        <button className='viewall'>ViewAll</button>
        </div>
        </>:null}
        
        <Proteinsnack/>
        <Vitamins/> */}
        <Producttype/>
        
        <About/>
        <h1 className="text-center brandhead">Brands</h1>
        <div className='row brandrange'>
        <div className='col'><Brands image={MBLogo} id="MBLogo"/></div>
        <div className='col'><Brands image={ONLogo} id="ONLogo"/></div>
        <div className='col'><Brands image={HFLogo} id="HFLogo"/></div>
        <div className='col'><Brands image={DymatizeLogo} id="DymatizeLogo"/></div>
        </div>
    
    </section>
    
}

export default Home;