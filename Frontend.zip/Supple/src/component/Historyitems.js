import React from 'react'
import moment from 'moment'


const Historyitems = (curr) => {
  return (
    <>
    
    <div className='historyitem'>
       
      <div className='usergrid'>
            <div><img src={curr.image} style={{width:100+"px"}}/></div>
            <div>{curr.name}</div>
            <div>{curr.amount}</div>
            <div>{curr.price}</div>
            <div>{curr.weight}</div>
            <div>{moment(curr.date).format('DD-MM-yyyy')}</div>
        </div>
    </div>
    </>
  )
}

export default Historyitems
