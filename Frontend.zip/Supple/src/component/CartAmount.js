import React from 'react'
import { FaPlus,FaMinus } from "react-icons/fa6";

const CartAmount = ({ amount,setDecrease,setIncrease}) => {
  return (
    <div className='amounttoggle'>
      <button className='minus' onClick={()=>setDecrease()}><FaMinus/></button>
      <div className='amount'>{amount}</div>
      <button className='plus' onClick={()=>setIncrease()}><FaPlus/></button>
    </div>
  )
}

export default CartAmount
