import React from 'react'
import { useFiltercontext } from '../context/filtercontext'

const Search = () => {
    const {filters:{text},updateVlaue}=useFiltercontext()

  return (
    <div className='searchitems'>
      <form onSubmit={(e)=>{e.preventDefault()}}> 
        <input type='text' name='text' value={text} onChange={updateVlaue} placeholder='Search' className='input'/>
      </form>
    </div>
  )
}

export default Search
